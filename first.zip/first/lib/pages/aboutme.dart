import 'package:flutter/material.dart';

class  AboutMe extends StatelessWidget {
  const AboutMe ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body : Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
              children: [Container(
height: 300,
width: 300,
decoration: BoxDecoration(
shape: BoxShape.circle,
image: DecorationImage(
image: AssetImage("assets/IMG-20231208-WA0002.jpeg")
),
boxShadow: [
BoxShadow(
color: Colors.black,
offset: Offset(0,0),
blurRadius: 4,
spreadRadius: 7,
),
],
),
),
                const SizedBox(width: 40,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "I just have 2 selfies \n both of them were bad",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color : Colors.black
                      ),
                    ),
                    const SizedBox(height : 20,),
                    Text("""The Picture that i have in the profile\n Is my drawing""",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize:20,
                      color:Colors.grey),
                    )
                  ]
                )]


)
    )
    );
  }
}

