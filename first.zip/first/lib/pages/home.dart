import 'package:flutter/material.dart' ;
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("My portfolio", style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.black
          ),),
        ),
        body: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("Hello, This is guru",
                        style: TextStyle(
                        fontSize : 30,
                        fontWeight: FontWeight.bold
                       ),
                    ),
                    Row(),
                    Text(
                        "I do not have my photo",
                         style: TextStyle(
                           fontSize: 25,
                           color: Colors.grey
                       ),
                    ),
                    TextButton(
                      onPressed:  () {
                        print("You are weak");
                        Navigator.pushNamed((context), '/about');
                      },
                      child: Text("About me",style :TextStyle(color : Colors.grey,fontSize: 17, fontWeight: FontWeight.bold)),
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.black)
    ),

              )
                  ],
                ),
                const SizedBox(width: 40,),
                Hero(
                  tag: 'IMG-20231208-WA0002.jpeg',
                  child: Container(
                    height: 300,
                    width: 300,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage("assets/IMG-20231208-WA0002.jpeg")
                          ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(0,0),
                            blurRadius: 4,
                            spreadRadius: 7
                          )
                        ]
                      )
                  ),
                ),
              ]
          ),
        ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Container(
        height: 50,
        width: 300,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius : BorderRadius.circular(50),


        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Padding(
            padding: const EdgeInsets.all(7.0),
            child: Image.asset('assets/email.png'),
          ),
          InkWell(
            onTap: () async {
              await launchUrl(Uri.parse("https://github.com/gurus2004"));
            },
            child: Padding(
              padding: const EdgeInsets.all(7.0),
              child: Image.asset('assets/github.png'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(7.0),
            child: Image.asset('assets/instagram.png'),
          ),
          Padding(
            padding: const EdgeInsets.all(7.0),
            child: Image.asset('assets/linkedin.png'),
          )
        ],
      ),)
    );
  }

}
