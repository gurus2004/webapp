//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import url_launcher_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  UrlLauncherPlugin.register(with: registry.registrar(forPlugin: "UrlLauncherPlugin"))
}
